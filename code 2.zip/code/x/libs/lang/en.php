<?php
define('HOME_BEMVINDO', 'Welcome');
define('HOME_TEXTO_BEMVINDO', 'Welcome to the webplayer login below please log in using your details.');
define('HOME_BOTAO_LOGIN', 'Login');
define('HOME_BOTAO_LOGIN', 'Login');
define('HOME_BOTAO_TESTE', 'Request / Trial Test');
define('HOME_TXT_LOGIN', 'Enter Web Player');
define('HOME_TXT_USER', 'Username');
define('HOME_TXT_PASS', 'Password');
define('HOME_TXT_TESTE', 'Free Trial');
define('HOME_TXT_TESTE_DESC', 'Register and Free Trial!');
define('HOME_TXT_HORAS', 'hour.');
define('HOME_CAMPO_WA', 'Enter your WhatsApp');
define('HOME_CAMPO_NOME', 'Enter Your Name');
define('HOME_CAMPO_EMAIL', 'Enter Your Email');

define('FILMES_SUGERIDOS', 'Film Recommendations');
define('SERIES_SUGERIDOS', 'Recommended Film Series');
define('CANAIS_AO_VIVO', 'Live Broadcast');
define('AO_VIVO', 'Live');

define('MENU_TV_AO_VIVO', 'Live TV');
define('MENU_HOME', 'Home');
define('MENU_SERIES', 'TV Series');
define('MENU_RENOVAR', 'Extend account.');
define('MENU_SAIR', 'Exit');

define('TXT_BEMVINDO', 'Welcome');
define('TXT_TELAS', 'Allowed screen');
define('TXT_VALIDADE', 'Valid Access to');
define('TXT_RESTAM', 'Left');
define('TXT_SERIES', 'Series');
define('TXT_SERIE', 'series');
define('TXT_TEMPORADA', 'Season');
define('TXT_EPISODIO', 'Episode');
define('TXT_TODAS_TEMPORADAS', 'See all seasons.');
define('TXT_CATEGORIAS', 'Category');
define('TXT_DURACAO', 'Duration');
define('TXT_FULLSCREEN', 'Full Screen');
define('TXT_INFO', 'Information');
define('TXT_DIRETOR', 'Director');
define('TXT_ELENCO', 'Register');
define('TXT_GENERO', 'Gender');
define('TXT_FILMES_SUGESTAO', 'Recommended Film');
define('TXT_CANAIS_SUGESTAO', 'Similar Channels');
define('TXT_ASSINATURA', 'Subscribe');
define('TXT_MES', '/ Month');
define('TXT_MOEDA', 'IDR');

define('TAG_VOD', 'Video On Demand');
define('TXT_COPYRIGHT', 'All Rights Reserved.');
define('ERROR_FORMATO_VIDEO', 'Sorry your browser does not yet support this video format');
define('ERROR_FORMATO_VIDEO_DESC', 'Sorry for the inconvenience, some browsers do not yet support all available video formats.');

define('TXT_DESCRICAO_ASSINATURA', 'Bank payments can take up to 24 working hours to be approved and confirmed by the issuing bank. Compensation from Tuesday to Saturday.');
define('TXT_DESCRICAO_ASSINATURA_DESCONTO', '* To delete an adult channel from the list, you can request by contacting our team via whatsapp.');
define('BOTAO_WHATSAPP', 'Whatsapp Service');
define('BOTAO_ASSINAR', 'Subscribe');
define('DESCRICAO_PLANOS', '<li> ± 6,000 Channels, Movies & Series </li>
<li> SD, HD and FULL HD channels </li>
<li> Adult Channels (Optional) </li>
<li> Film Box Office, Sports and Religion </li>
<li> Spanish Channel </li>
<li> Watch from anywhere </li> ');
