<?php
define('HOME_BEMVINDO','Bem Vindo');
define('HOME_TEXTO_BEMVINDO','Bem vindo ao webplayer faça o login abaixo utilizando seus dados.');
define('HOME_BOTAO_LOGIN','Entrar');
define('HOME_BOTAO_LOGIN','Entrar');
define('HOME_BOTAO_TESTE','Solicitar Teste');
define('HOME_TXT_LOGIN','Faça Seu Login');
define('HOME_TXT_USER','Usuário');
define('HOME_TXT_PASS','Senha');
define('HOME_TXT_TESTE','Teste Grátis');
define('HOME_TXT_TESTE_DESC','Cadastre-se e teste grátis');
define('HOME_TXT_HORAS','horas.');
define('HOME_CAMPO_WA','Informe seu WhastApp');
define('HOME_CAMPO_NOME','Informe seu Nome');
define('HOME_CAMPO_EMAIL','Informe seu Email');


define('FILMES_SUGERIDOS','Filmes Sugeridos');
define('SERIES_SUGERIDOS','Séries Sugeridas');
define('CANAIS_AO_VIVO','Canais ao Vivo');
define('AO_VIVO','Ao Vivo');

define('MENU_TV_AO_VIVO','TV ao Vivo');
define('MENU_HOME','Home');
define('MENU_SERIES','Séries');
define('MENU_RENOVAR','Renovar Assinatura');
define('MENU_SAIR','Sair');

define('TXT_BEMVINDO','Bem Vindo');
define('TXT_TELAS','Telas Permitidas');
define('TXT_VALIDADE','Acesso Válido Até');
define('TXT_RESTAM','Restam');
define('TXT_SERIES','Séries');
define('TXT_SERIE','Série');
define('TXT_TEMPORADA','Temporada');
define('TXT_EPISODIO','Episódio');
define('TXT_TODAS_TEMPORADAS','Ver Todas as Temporadas');
define('TXT_CATEGORIAS','Categorias');
define('TXT_DURACAO','DURAÇÃO');
define('TXT_FULLSCREEN','TELA CHEIA');
define('TXT_INFO','Informações');
define('TXT_DIRETOR','Diretor');
define('TXT_ELENCO','Elenco');
define('TXT_GENERO','Genero');
define('TXT_FILMES_SUGESTAO','Filmes Sugeridos');
define('TXT_CANAIS_SUGESTAO','Canais Semelhantes');
define('TXT_ASSINATURA','Assinatura');
define('TXT_MES','/ Mês');
define('TXT_MOEDA','R$');

define('TAG_VOD','Vods');
define('TXT_COPYRIGHT',' All Rights Reserved.');

define('ERROR_FORMATO_VIDEO','Desculpe seu navegador ainda não suporta este formato de vídeo');
define('ERROR_FORMATO_VIDEO_DESC','Sentimos muito por esse inconveniente alguns navegadores ainda não suportam todos os formatos de vídeos disponíveis.');

define('TXT_DESCRICAO_ASSINATURA','Pagamentos via Boleto Bancário podem levar até 24 horas úteis para serem aprovados e a sua confirmação é automática pelo banco emissor. Compensações de Terça à Sábado.');
define('TXT_DESCRICAO_ASSINATURA_DESCONTO','* Para a retirada de canais adultos da lista, deve ser solicitado a exclusão de sua lista. <br>Caso necessário, contate nossa equipe através do whatsapp.');
define('BOTAO_WHATSAPP','ATENDIMENTO VIA WHATSAPP');
define('BOTAO_ASSINAR','Assinar');
define('DESCRICAO_PLANOS','<li>±6.000  Canais, Filmes e Séries</li>
                                <li>Canais SD, HD e FULL HD</li>
                                <li>Canais Adultos (Opcional)</li>
                                <li>Desenhos, Esportes e Religiosos</li>
                                <li>Canais Brasileiros</li>
                                <li>Assista Onde Quiser</li>');