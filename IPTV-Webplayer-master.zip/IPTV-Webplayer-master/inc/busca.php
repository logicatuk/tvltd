<form>
<input type="search" id="busca" placeholder="Pesquisar">
</form>