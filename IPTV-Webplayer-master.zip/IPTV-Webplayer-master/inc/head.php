     <meta charset="utf-8"/>
      
	  <meta name="viewport" content="width=device-width, initial-scale=1"/>
	  <meta name="mobile-web-app-capable" content="yes"/>
	  <meta name="apple-mobile-web-app-capable" content="yes"/>
	  <meta name="viewport" content="target-densitydpi=device-dpi"/>	
      <meta name="description" content="<?php echo NOME_IPTV; ?>"/>      
      <meta http-equiv="X-UA-Compatible" content="IE=Edge" />
      <link rel="icon" type="image/png" href="assets/<?php echo $template; ?>/img/favicons.png" />
      <title><?php echo NOME_IPTV; ?></title>
      <link href="assets/<?php echo $template; ?>/css/bootstrap.css" rel="stylesheet"/>
      <link rel="stylesheet" href="assets/<?php echo $template; ?>/css/screen.css"/>
      <link rel="stylesheet" href="assets/<?php echo $template; ?>/css/animation.css"/>
      <!--[if IE 7]>
      <link rel="stylesheet" href="assets/<?php echo $template; ?>/css/fontello-ie7.css">
      <![endif]-->
      <link rel="stylesheet" href="assets/<?php echo $template; ?>/css/font-awesome.css"/>
      <!--[if lt IE 8]>
      <link rel="stylesheet" href="assets/<?php echo $template; ?>/css/ie.css" type="text/css" media="screen, projection">
      <![endif]-->
      <link href="assets/<?php echo $template; ?>/css/lity.css" rel="stylesheet"/>
      
      <script>
      	function go(to) { document.location.href=to; }
      </script>
      
