<!-- SECTION FOOTER -->
               <div class="row">
                  <!-- SOCIAL -->
                  <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                     <div class="row auto-clear">
                        <div class="col-md-12">
                        </div>
                        <div class="col-md-12">
                           
                        </div>
                        <div class="col-md-12">
                           
                        </div>
                     </div>
                  </div>
                  <!-- TAGS -->
                  <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                     
                     
                  </div>
                  <!-- POST -->
                  <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    
                  
                  </div>
                  <!-- LINKS -->
                  <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    
                    
                  </div>
               </div>
               <div class="row copyright-bottom text-center">
                  <div class="col-md-12 text-center">
                     <a href="javascript:void(0);" class="footer-logo" title="<?php echo NOME_IPTV; ?>">
                  
                    </a>	
           <p>&copy; Copyright <?php echo date('Y'); ?>. <?php echo TXT_COPYRIGHT; ?><br></p>
                     <a href="javascript:void(0);" title="<?php echo NOME_IPTV; ?>"><?php echo NOME_IPTV; ?></a>
                  </div>
               </div>
